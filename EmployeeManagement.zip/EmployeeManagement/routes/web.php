<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/employees_Form/open', [App\Http\Controllers\EmployeesController::class, 'openEmployeeForm']);
Route::post('/employees_Form/submit', [App\Http\Controllers\EmployeesController::class, 'submitEmployeesForm']);

Route::get('/departments_Form/open', [App\Http\Controllers\DepartmentsController::class, 'openDepartmentsForm']);
Route::post('/departments_Form/submit', [App\Http\Controllers\DepartmentsController::class, 'submitDepartmentsForm']);

Route::get('employees',[App\Http\Controllers\EmployeesController::class, 'getEmployees']);
Route::get('departments', [App\Http\Controllers\DepartmentsController::class, 'getDepartments']);

Route::get('/employees_Form/edit/{id}', [App\Http\Controllers\EmployeesController::class, 'editEmployee']);
Route::post('/employees_Form/update/{id}', [App\Http\Controllers\EmployeesController::class, 'updateEmployee']);

Route::get('/departments_Form/edit/{id}', [App\Http\Controllers\DepartmentsController::class, 'editDepartment']);
Route::post('/departments_Form/update/{id}', [App\Http\Controllers\DepartmentsController::class, 'updateDepartmentsForm']);

Route::get('/employees_Form/delete/{id}', [App\Http\Controllers\EmployeesController::class, 'deleteEmployee']);
Route::get('/departments_Form/delete/{id}', [App\Http\Controllers\DepartmentsController::class, 'deleteDepartment']);

Route::get('/search_employee/{name}', [App\Http\Controllers\EmployeesController::class, 'searchEmployee']);
Route::get('/search_department/{name}', [App\Http\Controllers\DepartmentsController::class, 'searchDepartment']);
