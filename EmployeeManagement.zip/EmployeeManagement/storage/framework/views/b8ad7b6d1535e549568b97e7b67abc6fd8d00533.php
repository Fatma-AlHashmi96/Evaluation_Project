<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="/departments_Form/submit" method='POST'>
        <?php echo csrf_field(); ?>
        <label for="">Name:</label>
        <input type="text" name="department_name">
        <br>

        <label for="">Status:</label>
        <input type="text" name='status'>
        <br>

        <input type="submit" value='Submit'>
    </form>
</body>
</html><?php /**PATH D:\Documents\Employee_System\EmployeeManagement\resources\views/departments_Form.blade.php ENDPATH**/ ?>