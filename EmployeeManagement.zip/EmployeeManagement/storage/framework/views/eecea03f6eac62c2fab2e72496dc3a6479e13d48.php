<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php if($records->isEmpty()): ?>
        <p>No Depetment found.</p>
    <?php else: ?>
    <table>
    <thead>
        <tr>
            <th>Name</th>
            <th>Status</th>
        </tr>
</thead>
    <tbody>
        <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($record->name); ?></td>
            <td><?php echo e($record->status); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
    </table>
 <?php endif; ?>  
</body>
</html><?php /**PATH D:\Documents\Employee_System\EmployeeManagement\resources\views/getDepartments.blade.php ENDPATH**/ ?>