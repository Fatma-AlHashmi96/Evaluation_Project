<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <?php if($records->isEmpty()): ?>
        <p>No employees found.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Phone Number</th>
                    <th>Age</th>
                    <th>Department ID</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($record->name); ?></td>
                        <td><?php echo e($record->phone_no); ?></td>
                        <td><?php echo e($record->age); ?></td>
                        <td><?php echo e($record->department_id); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>    
</body>
</html><?php /**PATH D:\Documents\Employee_System\EmployeeManagement\resources\views/getEmployees.blade.php ENDPATH**/ ?>