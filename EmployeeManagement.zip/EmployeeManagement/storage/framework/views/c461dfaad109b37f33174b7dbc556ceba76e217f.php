<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
   <form action="/employees_Form/update/<?php echo e($record->id); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <label for="">Name:</label>
    <input type="text" name="name" value='<?php echo e($record->name); ?>'>
    <br>

    <label for="">Phone Number:</label>
    <input type="text" name="phone_no" value='<?php echo e($record->phone_no); ?>'>
    <br>

    <label for="">Age:</label>
    <input type="number" name="age" value='<?php echo e($record->age); ?>'>
    <br>

    <label for="">Department ID:</label>
    <input type="number" name='department_id' value='<?php echo e($record->department_id); ?>'>
    <br>
     <input type="submit" value='Submit'>

   </form> 
</body>
</html><?php /**PATH D:\Documents\Employee_System\EmployeeManagement\resources\views/employeeEdit.blade.php ENDPATH**/ ?>