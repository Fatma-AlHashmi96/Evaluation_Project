<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
   <form action="/employees_Form/submit" method="POST">
    @csrf
    <label for="">Name:</label>
    <input type="text" name="name">
    <br>

    <label for="">Phone Number:</label>
    <input type="text" name="phone_no">
    <br>

    <label for="">Age:</label>
    <input type="number" name="age">
    <br>

    <label for="">Department ID:</label>
    <input type="number" name='department_id'>
    <br>
     <input type="submit" value='Submit'>

   </form> 
</body>
</html>