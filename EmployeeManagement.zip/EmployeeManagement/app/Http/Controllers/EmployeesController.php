<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Employee;

class EmployeesController extends Controller
{
    public function openEmployeeForm()
    {
        return view('employees_Form');
    }

    public function submitEmployeesForm(Request $request)
    {
        $record=new Employee();
        $record->name=$request->name;
        $record->phone_no=$request->phone_no;
        $record->age=$request->age;
        $record->department_id=$request->department_id;
        $record->save();
        return 'Added Record Successfully';


        // return $request;
    }

    public function getEmployees()
    {
        $data['records']= Employee::all();
        return view('getEmployees', $data);
    }

   public function editEmployee($id)
   {
    $data['record']= Employee::findorFail($id);
    return view('employeeEdit', $data);
   }
   public function updateEmployee(Request $request, $id)
   {
       $record=Employee::find($id);
       $record->name=$request->name;
       $record->phone_no=$request->phone_no;
       $record->age=$request->age;
       $record->department_id=$request->department_id;
       $record->save();
       return 'Record Updatted Successfully';
   }

   public function deleteEmployee($id)
   {
    $record=Employee::find($id);
    $record->delete();
    return 'Record Deleted Succefully';
   }

  
 public function searchEmployee(Request $request, $name = null) {
    $phone = $request->phone_number;

    $employees = Employee::query();

    if ($name) {
        $employees->where('name', 'like', "%$name%");
    }

    if ($phone) {
        $employees->where('phone_no', $phone);
    }

    $results = $employees->get();

    return view('getEmployees', ['records' => $results]);
 }

}
