<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Department;

class DepartmentsController extends Controller
{
    public function openDepartmentsForm()
    {
      return view('departments_Form');  
    }

    public function submitDepartmentsForm(Request $request)
    {
      $record=new Department();
      $record->name=$request->department_name;
      $record->status=$request->status;
      $record->save();
      return 'Added record successfully';
        // return $request;
    }
    public function getDepartments()
    {
        $data['records']= Department::all();
        return view('getDepartments',$data );
    }


    public function editDepartment($id)
    {
      $data['record']=Department::findorFail($id);
      return view('editDepartment', $data);
    }
    public function updateDepartmentsForm(Request $request, $id)
    {
      $record=Department::find($id);
      $record->name=$request->department_name;
      $record->status=$request->status;
      $record->save();
      return 'record Updated successfully';
        
    }

    public function deleteDepartment($id)
    {
      $record= Department::find($id);
      $record->delete();
      return 'Record Deleted Successfully';
    }

    public function searchDepartment(Request $request, $name = null) {
  
      $departments = Department::query();
  
      if ($name) {
          $departments->where('name', 'like', "%$name%");
      }
  
  
      $results = $departments->get();
  
      return view('getDepartments', ['records' => $results]);
   }
  
}
